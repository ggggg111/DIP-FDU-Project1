class AllInOneBlock(Module):
  __parameters__ = ["global_scale", "global_offset", "w_perm", "w_perm_inv", ]
  __buffers__ = []
  global_scale : Tensor
  global_offset : Tensor
  w_perm : Tensor
  w_perm_inv : Tensor
  training : bool
  _is_full_backward_hook : Optional[bool]
  softplus : __torch__.torch.nn.modules.activation.___torch_mangle_148.Softplus
  subnet : __torch__.torch.nn.modules.container.___torch_mangle_152.Sequential
  def forward(self: __torch__.FrEIA.modules.all_in_one_block.___torch_mangle_153.AllInOneBlock,
    argument_1: Tensor) -> Tuple[Tensor, Tensor]:
    _0 = self.w_perm
    _1 = self.global_offset
    _2 = self.global_scale
    _3 = self.softplus
    _4 = self.subnet
    _5 = torch.split_with_sizes(argument_1, [128, 128], 1)
    input, x, = _5
    a = torch.mul_((_4).forward(input, ), CONSTANTS.c2)
    ch = ops.prim.NumToTensor(torch.size(x, 1))
    _6 = int(ch)
    _7 = int(ch)
    _8 = torch.slice(a, 0, 0, 9223372036854775807)
    _9 = torch.tanh(torch.slice(_8, 1, 0, _7))
    sub_jac = torch.mul(_9, CONSTANTS.c3)
    _10 = torch.mul(x, torch.exp(sub_jac))
    _11 = torch.slice(a, 0, 0, 9223372036854775807)
    _12 = torch.slice(_11, 1, _6, 9223372036854775807)
    x2 = torch.add(_10, _12)
    j2 = torch.sum(sub_jac, [1, 2, 3])
    x0 = torch.cat([input, x2], 1)
    scale = torch.mul((_3).forward(_2, ), CONSTANTS.c2)
    global_scaling_jac = torch.sum(torch.log(scale))
    x_out = torch._convolution(torch.add(torch.mul(x0, scale), _1), _0, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1, False, False, True, True)
    _13 = torch.mul(global_scaling_jac, CONSTANTS.c6)
    j = torch.add_(j2, _13)
    return (j, x_out)
