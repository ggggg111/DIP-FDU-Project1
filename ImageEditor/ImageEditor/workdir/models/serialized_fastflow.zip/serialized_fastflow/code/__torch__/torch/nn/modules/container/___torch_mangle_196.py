class ModuleList(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  __annotations__["0"] = __torch__.FrEIA.modules.all_in_one_block.___torch_mangle_153.AllInOneBlock
  __annotations__["1"] = __torch__.FrEIA.modules.all_in_one_block.___torch_mangle_159.AllInOneBlock
  __annotations__["2"] = __torch__.FrEIA.modules.all_in_one_block.___torch_mangle_165.AllInOneBlock
  __annotations__["3"] = __torch__.FrEIA.modules.all_in_one_block.___torch_mangle_171.AllInOneBlock
  __annotations__["4"] = __torch__.FrEIA.modules.all_in_one_block.___torch_mangle_177.AllInOneBlock
  __annotations__["5"] = __torch__.FrEIA.modules.all_in_one_block.___torch_mangle_183.AllInOneBlock
  __annotations__["6"] = __torch__.FrEIA.modules.all_in_one_block.___torch_mangle_189.AllInOneBlock
  __annotations__["7"] = __torch__.FrEIA.modules.all_in_one_block.___torch_mangle_195.AllInOneBlock
