class FeatureListNet(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv1 : __torch__.torch.nn.modules.conv.Conv2d
  bn1 : __torch__.torch.nn.modules.batchnorm.BatchNorm2d
  act1 : __torch__.torch.nn.modules.activation.ReLU
  maxpool : __torch__.torch.nn.modules.pooling.MaxPool2d
  layer1 : __torch__.torch.nn.modules.container.Sequential
  layer2 : __torch__.torch.nn.modules.container.___torch_mangle_30.Sequential
  layer3 : __torch__.torch.nn.modules.container.___torch_mangle_48.Sequential
  def forward(self: __torch__.timm.models.features.FeatureListNet,
    x: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
    _0 = self.layer3
    _1 = self.layer2
    _2 = self.layer1
    _3 = self.maxpool
    _4 = self.act1
    _5 = (self.bn1).forward((self.conv1).forward(x, ), )
    _6 = (_2).forward((_3).forward((_4).forward(_5, ), ), )
    _7 = (_1).forward(_6, )
    return (_6, _7, (_0).forward(_7, ))
