class BasicBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv1 : __torch__.torch.nn.modules.conv.___torch_mangle_6.Conv2d
  bn1 : __torch__.torch.nn.modules.batchnorm.___torch_mangle_7.BatchNorm2d
  act1 : __torch__.torch.nn.modules.activation.___torch_mangle_8.ReLU
  conv2 : __torch__.torch.nn.modules.conv.___torch_mangle_9.Conv2d
  bn2 : __torch__.torch.nn.modules.batchnorm.___torch_mangle_10.BatchNorm2d
  act2 : __torch__.torch.nn.modules.activation.___torch_mangle_11.ReLU
  def forward(self: __torch__.timm.models.resnet.___torch_mangle_12.BasicBlock,
    argument_1: Tensor) -> Tensor:
    _0 = self.act2
    _1 = self.bn2
    _2 = self.conv2
    _3 = self.act1
    _4 = (self.bn1).forward((self.conv1).forward(argument_1, ), )
    _5 = (_1).forward((_2).forward((_3).forward(_4, ), ), )
    input = torch.add_(_5, argument_1)
    return (_0).forward(input, )
