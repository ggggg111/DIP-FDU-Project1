class Sequential(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  __annotations__["0"] = __torch__.timm.models.resnet.BasicBlock
  __annotations__["1"] = __torch__.timm.models.resnet.___torch_mangle_12.BasicBlock
  def forward(self: __torch__.torch.nn.modules.container.Sequential,
    argument_1: Tensor) -> Tensor:
    _0 = getattr(self, "1")
    _1 = (getattr(self, "0")).forward(argument_1, )
    return (_0).forward(_1, )
class ModuleList(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  __annotations__["0"] = __torch__.torch.nn.modules.normalization.LayerNorm
  __annotations__["1"] = __torch__.torch.nn.modules.normalization.___torch_mangle_49.LayerNorm
  __annotations__["2"] = __torch__.torch.nn.modules.normalization.___torch_mangle_50.LayerNorm
