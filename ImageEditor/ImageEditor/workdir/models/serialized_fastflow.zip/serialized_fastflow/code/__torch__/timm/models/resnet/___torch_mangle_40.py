class BasicBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv1 : __torch__.torch.nn.modules.conv.___torch_mangle_31.Conv2d
  bn1 : __torch__.torch.nn.modules.batchnorm.___torch_mangle_32.BatchNorm2d
  act1 : __torch__.torch.nn.modules.activation.___torch_mangle_33.ReLU
  conv2 : __torch__.torch.nn.modules.conv.___torch_mangle_34.Conv2d
  bn2 : __torch__.torch.nn.modules.batchnorm.___torch_mangle_35.BatchNorm2d
  act2 : __torch__.torch.nn.modules.activation.___torch_mangle_36.ReLU
  downsample : __torch__.torch.nn.modules.container.___torch_mangle_39.Sequential
  def forward(self: __torch__.timm.models.resnet.___torch_mangle_40.BasicBlock,
    argument_1: Tensor) -> Tensor:
    _0 = self.act2
    _1 = self.downsample
    _2 = self.bn2
    _3 = self.conv2
    _4 = self.act1
    _5 = (self.bn1).forward((self.conv1).forward(argument_1, ), )
    _6 = (_2).forward((_3).forward((_4).forward(_5, ), ), )
    input = torch.add_(_6, (_1).forward(argument_1, ))
    return (_0).forward(input, )
