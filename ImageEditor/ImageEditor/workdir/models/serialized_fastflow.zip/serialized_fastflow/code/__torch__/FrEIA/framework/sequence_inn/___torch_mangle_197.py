class SequenceINN(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  module_list : __torch__.torch.nn.modules.container.___torch_mangle_196.ModuleList
  def forward(self: __torch__.FrEIA.framework.sequence_inn.___torch_mangle_197.SequenceINN,
    argument_1: Tensor) -> Tuple[Tensor, Tensor]:
    _0 = getattr(self.module_list, "7")
    _1 = getattr(self.module_list, "6")
    _2 = getattr(self.module_list, "5")
    _3 = getattr(self.module_list, "4")
    _4 = getattr(self.module_list, "3")
    _5 = getattr(self.module_list, "2")
    _6 = getattr(self.module_list, "1")
    _7 = (getattr(self.module_list, "0")).forward(argument_1, )
    _8, _9, = _7
    log_det_jac = torch.add(_8, CONSTANTS.c1)
    _10, _11, = (_6).forward(_9, )
    log_det_jac0 = torch.add(_10, log_det_jac)
    _12, _13, = (_5).forward(_11, )
    log_det_jac1 = torch.add(_12, log_det_jac0)
    _14, _15, = (_4).forward(_13, )
    log_det_jac2 = torch.add(_14, log_det_jac1)
    _16, _17, = (_3).forward(_15, )
    log_det_jac3 = torch.add(_16, log_det_jac2)
    _18, _19, = (_2).forward(_17, )
    log_det_jac4 = torch.add(_18, log_det_jac3)
    _20, _21, = (_1).forward(_19, )
    log_det_jac5 = torch.add(_20, log_det_jac4)
    _22, _23, = (_0).forward(_21, )
    log_jac_dets = torch.add(_22, log_det_jac5)
    return (_23, log_jac_dets)
