class ModuleList(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  __annotations__["0"] = __torch__.FrEIA.modules.all_in_one_block.AllInOneBlock
  __annotations__["1"] = __torch__.FrEIA.modules.all_in_one_block.___torch_mangle_60.AllInOneBlock
  __annotations__["2"] = __torch__.FrEIA.modules.all_in_one_block.___torch_mangle_66.AllInOneBlock
  __annotations__["3"] = __torch__.FrEIA.modules.all_in_one_block.___torch_mangle_72.AllInOneBlock
  __annotations__["4"] = __torch__.FrEIA.modules.all_in_one_block.___torch_mangle_78.AllInOneBlock
  __annotations__["5"] = __torch__.FrEIA.modules.all_in_one_block.___torch_mangle_84.AllInOneBlock
  __annotations__["6"] = __torch__.FrEIA.modules.all_in_one_block.___torch_mangle_90.AllInOneBlock
  __annotations__["7"] = __torch__.FrEIA.modules.all_in_one_block.___torch_mangle_96.AllInOneBlock
