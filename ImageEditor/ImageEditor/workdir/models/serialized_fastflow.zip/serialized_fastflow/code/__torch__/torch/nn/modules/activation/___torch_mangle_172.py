class Softplus(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.torch.nn.modules.activation.___torch_mangle_172.Softplus,
    input: Tensor) -> Tensor:
    return torch.softplus(input, 0.5)
