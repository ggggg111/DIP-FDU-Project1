class Conv2d(Module):
  __parameters__ = ["weight", "bias", ]
  __buffers__ = []
  weight : Tensor
  bias : Tensor
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.torch.nn.modules.conv.___torch_mangle_191.Conv2d,
    input: Tensor) -> Tensor:
    _0 = self.bias
    input0 = torch._convolution_mode(input, self.weight, _0, [1, 1], "same", [1, 1], 1)
    return input0
