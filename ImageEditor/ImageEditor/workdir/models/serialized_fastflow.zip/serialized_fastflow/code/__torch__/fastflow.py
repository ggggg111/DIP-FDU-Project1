class FastFlow(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  feature_extractor : __torch__.timm.models.features.FeatureListNet
  norms : __torch__.torch.nn.modules.container.ModuleList
  nf_flows : __torch__.torch.nn.modules.container.___torch_mangle_198.ModuleList
  def forward(self: __torch__.fastflow.FastFlow,
    x: Tensor) -> Dict[str, Tensor]:
    _0 = getattr(self.nf_flows, "2")
    _1 = getattr(self.nf_flows, "1")
    _2 = getattr(self.nf_flows, "0")
    _3 = getattr(self.norms, "2")
    _4 = getattr(self.norms, "1")
    _5 = getattr(self.norms, "0")
    _6 = (self.feature_extractor).forward(x, )
    _7, _8, _9, = _6
    _10 = (_5).forward(_7, )
    _11 = (_4).forward(_8, )
    _12 = (_3).forward(_9, )
    _13, _14, = (_2).forward(_10, )
    _15 = torch.sum(torch.pow(_13, 2), [1, 2, 3])
    _16 = torch.sub(torch.mul(_15, CONSTANTS.c0), _14)
    loss = torch.add(torch.mean(_16), CONSTANTS.c1)
    _17, _18, = (_1).forward(_11, )
    _19 = torch.sum(torch.pow(_17, 2), [1, 2, 3])
    _20 = torch.sub(torch.mul(_19, CONSTANTS.c0), _18)
    loss0 = torch.add_(loss, torch.mean(_20))
    _21, _22, = (_0).forward(_12, )
    _23 = torch.sum(torch.pow(_21, 2), [1, 2, 3])
    _24 = torch.sub(torch.mul(_23, CONSTANTS.c0), _22)
    _25 = torch.add_(loss0, torch.mean(_24))
    _26 = torch.mean(torch.pow(_13, 2), [1], True)
    log_prob = torch.mul(torch.neg(_26), CONSTANTS.c0)
    prob = torch.exp(log_prob)
    input = torch.neg(prob)
    _27 = torch.upsample_bilinear2d(input, [256, 256], False, None)
    _28 = torch.mean(torch.pow(_17, 2), [1], True)
    log_prob0 = torch.mul(torch.neg(_28), CONSTANTS.c0)
    prob0 = torch.exp(log_prob0)
    input0 = torch.neg(prob0)
    _29 = torch.upsample_bilinear2d(input0, [256, 256], False, None)
    _30 = torch.mean(torch.pow(_21, 2), [1], True)
    log_prob1 = torch.mul(torch.neg(_30), CONSTANTS.c0)
    prob1 = torch.exp(log_prob1)
    input1 = torch.neg(prob1)
    a_map = torch.upsample_bilinear2d(input1, [256, 256], False, None)
    anomaly_map_list = torch.stack([_27, _29, a_map], -1)
    _31 = {"loss": _25, "anomaly_map": torch.mean(anomaly_map_list, [-1])}
    return _31
