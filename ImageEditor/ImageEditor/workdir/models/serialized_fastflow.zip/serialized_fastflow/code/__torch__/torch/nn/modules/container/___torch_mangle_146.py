class ModuleList(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  __annotations__["0"] = __torch__.FrEIA.modules.all_in_one_block.___torch_mangle_103.AllInOneBlock
  __annotations__["1"] = __torch__.FrEIA.modules.all_in_one_block.___torch_mangle_109.AllInOneBlock
  __annotations__["2"] = __torch__.FrEIA.modules.all_in_one_block.___torch_mangle_115.AllInOneBlock
  __annotations__["3"] = __torch__.FrEIA.modules.all_in_one_block.___torch_mangle_121.AllInOneBlock
  __annotations__["4"] = __torch__.FrEIA.modules.all_in_one_block.___torch_mangle_127.AllInOneBlock
  __annotations__["5"] = __torch__.FrEIA.modules.all_in_one_block.___torch_mangle_133.AllInOneBlock
  __annotations__["6"] = __torch__.FrEIA.modules.all_in_one_block.___torch_mangle_139.AllInOneBlock
  __annotations__["7"] = __torch__.FrEIA.modules.all_in_one_block.___torch_mangle_145.AllInOneBlock
